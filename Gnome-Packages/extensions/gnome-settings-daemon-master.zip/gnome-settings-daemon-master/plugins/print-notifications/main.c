#define NEW gsd_print_notifications_manager_new
#define START gsd_print_notifications_manager_start
#define STOP gsd_print_notifications_manager_stop
#define MANAGER GsdPrintNotificationsManager
#include "gsd-print-notifications-manager.h"

#include "daemon-skeleton.h"
