#define NEW gsd_usb_protection_manager_new
#define START gsd_usb_protection_manager_start
#define STOP gsd_usb_protection_manager_stop
#define MANAGER GsdUsbProtectionManager
#include "gsd-usb-protection-manager.h"

#include "daemon-skeleton.h"
