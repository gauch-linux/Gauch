#define NEW gsd_smartcard_manager_new
#define START gsd_smartcard_manager_start
#define STOP gsd_smartcard_manager_stop
#define MANAGER GsdSmartcardManager
#include "gsd-smartcard-manager.h"

#include "daemon-skeleton.h"
