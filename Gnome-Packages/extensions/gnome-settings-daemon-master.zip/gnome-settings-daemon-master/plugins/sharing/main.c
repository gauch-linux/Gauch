#define NEW gsd_sharing_manager_new
#define START gsd_sharing_manager_start
#define STOP gsd_sharing_manager_stop
#define MANAGER GsdSharingManager
#include "gsd-sharing-manager.h"

#include "daemon-skeleton.h"
