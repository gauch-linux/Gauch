#define NEW gsd_xsettings_manager_new
#define START gsd_xsettings_manager_start
#define STOP gsd_xsettings_manager_stop
#define MANAGER GsdXSettingsManager
#define GDK_BACKEND "x11"
#include "gsd-xsettings-manager.h"

#include "daemon-skeleton-gtk.h"
