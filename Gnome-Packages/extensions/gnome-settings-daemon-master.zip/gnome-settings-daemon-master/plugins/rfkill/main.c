#define NEW gsd_rfkill_manager_new
#define START gsd_rfkill_manager_start
#define STOP gsd_rfkill_manager_stop
#define MANAGER GsdRfkillManager
#include "gsd-rfkill-manager.h"

#include "daemon-skeleton.h"
