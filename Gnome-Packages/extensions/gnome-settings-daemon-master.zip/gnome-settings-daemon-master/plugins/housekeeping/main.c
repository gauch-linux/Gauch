#define NEW gsd_housekeeping_manager_new
#define START gsd_housekeeping_manager_start
#define STOP gsd_housekeeping_manager_stop
#define MANAGER GsdHousekeepingManager
#include "gsd-housekeeping-manager.h"

#include "daemon-skeleton.h"
