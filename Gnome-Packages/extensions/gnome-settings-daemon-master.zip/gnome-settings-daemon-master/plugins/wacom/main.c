#define NEW gsd_wacom_manager_new
#define START gsd_wacom_manager_start
#define STOP gsd_wacom_manager_stop
#define MANAGER GsdWacomManager
#include "gsd-wacom-manager.h"

#include "daemon-skeleton-gtk.h"
