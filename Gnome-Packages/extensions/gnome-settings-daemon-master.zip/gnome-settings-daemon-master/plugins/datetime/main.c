#define NEW gsd_datetime_manager_new
#define START gsd_datetime_manager_start
#define STOP gsd_datetime_manager_stop
#define MANAGER GsdDatetimeManager
#include "gsd-datetime-manager.h"

#include "daemon-skeleton.h"
