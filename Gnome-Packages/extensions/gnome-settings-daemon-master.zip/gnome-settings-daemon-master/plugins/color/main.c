#define NEW gsd_color_manager_new
#define START gsd_color_manager_start
#define STOP gsd_color_manager_stop
#define MANAGER GsdColorManager
#include "gsd-color-manager.h"

#include "daemon-skeleton-gtk.h"
