#define NEW gsd_screensaver_proxy_manager_new
#define START gsd_screensaver_proxy_manager_start
#define STOP gsd_screensaver_proxy_manager_stop
#define MANAGER GsdScreensaverProxyManager
#include "gsd-screensaver-proxy-manager.h"

#include "daemon-skeleton.h"
