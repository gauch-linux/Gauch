#define NEW gsd_wwan_manager_new
#define START gsd_wwan_manager_start
#define STOP gsd_wwan_manager_stop
#define MANAGER GsdWwanManager
#include "gsd-wwan-manager.h"

#include "daemon-skeleton.h"
