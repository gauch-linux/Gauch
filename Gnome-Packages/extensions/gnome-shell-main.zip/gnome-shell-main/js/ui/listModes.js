import './environment.js';

import {listModes} from './sessionMode.js';

listModes();
