baseURLs = [
    [ 'GLib', 'https://docs.gtk.org/glib/' ],
    [ 'GObject', 'https://docs.gtk.org/gobject/' ],
    [ 'Gio', 'https://docs.gtk.org/gio/' ],
    [ 'GdkPixbuf', 'https://docs.gtk.org/gdk-pixbuf/' ],
    [ 'Meta', 'https://mutter.gnome.org/meta/' ],
    [ 'Mtk', 'https://mutter.gnome.org/mtk/' ],
    [ 'Cogl', 'https://mutter.gnome.org/cogl/' ],
    [ 'Clutter', 'https://mutter.gnome.org/clutter/' ],
    [ 'St', 'https://gnome.pages.gitlab.gnome.org/gnome-shell/st/' ],
]
