baseURLs = [
    [ 'GLib', 'https://docs.gtk.org/glib/' ],
    [ 'GObject', 'https://docs.gtk.org/gobject/' ],
    [ 'Gio', 'https://docs.gtk.org/gio/' ],
    [ 'Pango', 'https://docs.gtk.org/pango/' ],
    [ 'GdkPixbuf', 'https://docs.gtk.org/gdk-pixbuf/' ],
    [ 'Clutter', 'https://mutter.gnome.org/clutter/' ],
    [ 'Cogl', 'https://mutter.gnome.org/cogl/' ],
    [ 'Meta', 'https://mutter.gnome.org/meta/' ],
]
