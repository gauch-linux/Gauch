/* -*- mode: C; c-file-style: "gnu"; indent-tabs-mode: nil; -*- */
#pragma once

#include "shell-tray-icon.h"

#include "na-tray-child.h"

ClutterActor * shell_tray_icon_new (NaTrayChild *tray_child);
