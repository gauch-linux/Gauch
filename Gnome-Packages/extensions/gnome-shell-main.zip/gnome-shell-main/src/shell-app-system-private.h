/* -*- mode: C; c-file-style: "gnu"; indent-tabs-mode: nil; -*- */
#pragma once

#include "shell-app-system.h"

void _shell_app_system_notify_app_state_changed (ShellAppSystem *self, ShellApp *app);
